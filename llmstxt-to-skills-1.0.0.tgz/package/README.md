# llmstxt-to-skills

Generate Claude-compatible skills from `llms.txt` sources.

## Run with npx

```bash
npx llmstxt-to-skills --url https://example.com/llms.txt
```

No global install is required.

## Commands

```bash
llmstxt-to-skills --url <llms.txt-url> [--output-dir ./skills] [--include <glob>] [--exclude <glob>]
llmstxt-to-skills init [--registry ./.claude-skills-registry.toml]
llmstxt-to-skills add <url> [--include <glob>] [--exclude <glob>] [--registry <path>]
llmstxt-to-skills list [--registry <path>]
llmstxt-to-skills update [--source <url>] [--registry <path>] [--output-dir <dir>]
```

## Local development

```bash
npm run smoke:help
```

## Publish to npm

1. Ensure the package name is available:
```bash
npm view llmstxt-to-skills
```
2. Login:
```bash
npm login
```
3. Publish:
```bash
npm publish --access public
```

After publishing, users can run:

```bash
npx llmstxt-to-skills --url https://example.com/llms.txt
```
